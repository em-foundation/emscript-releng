//$(LICENSE_COMMENT)

#if defined (__clang__)
#include <arm/arm_acle.h>
#else
#include <gcc/arm_acle.h>
#endif
