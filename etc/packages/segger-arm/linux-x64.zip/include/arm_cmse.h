//$(LICENSE_COMMENT)

#if defined (__clang__)
#include <arm/arm_cmse.h>
#else
#include <gcc/arm_cmse.h>
#endif
