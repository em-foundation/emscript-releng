//$(LICENSE_COMMENT)

#if defined (__clang__)
#include <arm/arm_mve.h>
#else
#include <gcc/arm_mve.h>
#endif
