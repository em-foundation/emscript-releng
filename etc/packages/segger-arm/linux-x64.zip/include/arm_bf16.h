//$(LICENSE_COMMENT)

#if defined (__clang__)
#include <arm/arm_bf16.h>
#else
#include <gcc/arm_bf16.h>
#endif
