//$(LICENSE_COMMENT)

#if defined (__clang__)
#include <arm/arm_fp16.h>
#else
#include <gcc/arm_fp16.h>
#endif
