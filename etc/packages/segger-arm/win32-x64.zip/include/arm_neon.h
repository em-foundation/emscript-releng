//$(LICENSE_COMMENT)

#if defined (__clang__)
#include <arm/arm_neon.h>
#else
#include <gcc/arm_neon.h>
#endif
