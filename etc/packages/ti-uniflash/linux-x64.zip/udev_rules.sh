#!/bin/bash

sudo cp 71-ti-permissions.rules /etc/udev/rules.d/
sudo chmod 644 /etc/udev/rules.d/71-ti-permissions.rules
sudo udevadm control --reload-rules
sudo udevadm trigger
