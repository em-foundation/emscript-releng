#!/bin/sh
set -eu
tool_dir=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)
mode=noConnectFlash
if [ "${1:-}" = "--mode" ]; then
    mode=${2:?missing DSLite mode}
    shift 2
fi
exec "$tool_dir/ccs_base/DebugServer/bin/DSLite" "$mode" "$@"
